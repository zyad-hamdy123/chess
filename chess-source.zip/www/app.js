import { Chess } from './chess.js';
const $ = (s) => document.querySelector(s);
const LEVELS = [
  { n: 'مبتدئ', elo: 1350 }, { n: 'هاوي', elo: 1600 }, { n: 'متوسط', elo: 1900 },
  { n: 'قوي', elo: 2200 }, { n: 'محترف', elo: 2600 }, { n: 'ماستر', elo: 3000 }, { n: 'الأقصى', elo: 0 },
];
const TIMES = [3000, 10000, 20000, 40000, 60000];
const GLYPH = { k: '\u265A', q: '\u265B', r: '\u265C', b: '\u265D', n: '\u265E', p: '\u265F' };
const NS = (typeof window !== 'undefined' && window.NStore) ? window.NStore : null;
const store = {
  ok: null, last: 0, native: !!NS,
  get(k, d) {
    try {
      let v = null;
      if (NS) { try { v = NS.get(k); } catch (e) { v = null; } }
      if (!v) { try { v = localStorage.getItem(k); } catch (e) { v = null; } if (v && NS) { try { NS.set(k, v); } catch (e) {} } }
      return v ? JSON.parse(v) : d;
    } catch (e) { return d; }
  },
  set(k, v) {
    let str; try { str = JSON.stringify(v); } catch (e) { return false; }
    let ok = false;
    if (NS) { try { ok = NS.set(k, str) === true; } catch (e) { ok = false; } }
    try { localStorage.setItem(k, str); if (!NS) ok = true; } catch (e) {}
    this.ok = ok; if (ok) this.last = Date.now(); return ok;
  },
};
const S = Object.assign({ eng: 'lite', time: 10000, level: 6, an: true, ar: true, co: true, mode: 'ai', color: 'w', thr: 1, dr: false, bm: true, sv: true, safe: false, perf: 'bal', v: 153, theme: 'purple', cl: '#f0d9b5', cd: '#b58863' }, store.get('zc_set', {}));
if (!TIMES.includes(S.time)) S.time = 10000;
if (!(S.v >= 160)) { S.v = 160; S.perf = S.perf === 'max' ? 'bal' : (S.perf || 'bal'); if (S.time > 10000) S.time = 10000; store.set('zc_set', S); }
if (!(S.v >= 153)) { S.v = 153; S.thr = 0; S.perf = S.safe ? 'safe' : 'bal'; S.bm = true; store.set('zc_set', S); }
S.safe = S.perf === 'safe';
const game = new Chess();
let humanColor = 'w', orient = 'w', sel = null, hintActive = false, thinking = false, A = null, over = false, bootErr = '';
let pendingPromo = null, mtFailed = false;
const HC = navigator.hardwareConcurrency || 1;
function canMT() { return !S.safe && !mtFailed && S.thr !== 1 && self.crossOriginIsolated === true && typeof SharedArrayBuffer !== 'undefined' && HC >= 2; }
function thrCount() { return S.thr > 1 ? Math.min(S.thr, HC, 8) : S.perf === 'max' ? Math.max(2, Math.min(HC - 1, 6)) : Math.min(3, Math.max(2, Math.floor(HC / 2))); }
function hashMB() { return S.perf === 'safe' ? 16 : S.perf === 'max' ? (eng.kind === 'mt' ? 64 : 48) : (eng.kind === 'mt' ? 32 : 24); }
const anCmd = () => S.perf === 'safe' ? 'go depth 16 movetime 4000' : S.perf === 'max' ? 'go depth 40 movetime 30000' : 'go depth 24 movetime 10000';
const nw = { mode: S.mode, color: S.color, level: S.level };

function toast(t, ms = 2600) { const e = $('#toast'); e.textContent = t; e.style.display = 'block'; clearTimeout(toast.t); toast.t = setTimeout(() => (e.style.display = 'none'), ms); }
function saveSet() { store.set('zc_set', S); }
function flashSaved() { const e = $('#svd'); if (!e) return; if (!game.history().length && !redo.length) return; e.textContent = store.ok ? '✓ اتحفظت' : '⚠ مش بتتحفظ'; e.className = store.ok ? 'on' : 'on bad'; clearTimeout(flashSaved.t); flashSaved.t = setTimeout(() => { e.className = ''; }, 1500); }
function saveTest() {
  const k = 'zc_test', val = 'ok' + Date.now(); store.set(k, { v: val });
  let back = null; try { back = NS ? JSON.parse(NS.sync(k)).v : JSON.parse(localStorage.getItem(k)).v; } catch (e) {}
  const good = back === val; toast((good ? '✓ الحفظ شغال. ' : '⚠ الحفظ فشل. ') + 'التخزين: ' + (NS ? 'داخلي في التطبيق' : 'المتصفح') + ' · ألعاب محفوظة: ' + GAMES.length, 4500);
}
window.__flush = () => { try { if (!REVIEW) { saveNow(); } } catch (e) {} return true; };
function saveRec() { const k = Object.keys(REC); if (k.length > 400) k.slice(0, k.length - 400).forEach((x) => delete REC[x]); store.set('zc_rec', REC); }
function saveNow() { if (REVIEW || S.sv === false) return; clearTimeout(saveGame.t); saveGame.t = null; saveRec(); saveRecord(); store.set('zc_game', { pgn: game.pgn(), humanColor, orient, mode: S.mode, redo, gid }); flashSaved(); }
function saveGame() { if (REVIEW || S.sv === false) return; clearTimeout(saveGame.t); saveGame.t = setTimeout(saveNow, 500); }

/* ---------------- engine ---------------- */
class Engine {
  constructor() { this.buf = {}; this.ft = null; this.last = Date.now(); this.w = null; this.ready = false; this.cur = null; this.pending = null; this.kind = null; this.nps = 0; }
  start(kind, onReady) {
    this.stop_worker(); this.kind = kind; this.ready = false; this.onReady = onReady;
    const file = kind === 'mt' ? 'sf/stockfish-19-lite.js' : 'sf/stockfish-19-lite-single.js';
    try { this.w = new Worker(file); } catch (e) { this.fail(String(e)); return; }
    const w = this.w;
    w.onmessage = (e) => { if (w === this.w) { this.last = Date.now(); this.line(typeof e.data === 'string' ? e.data : String(e.data && e.data.data || e.data)); } };
    w.onerror = (e) => { if (w === this.w) this.fail(e.message || 'worker error'); };
    this.send('uci');
    clearTimeout(this.wd);
    this.wd = setTimeout(() => { if (!this.ready && w === this.w) this.fail('timeout'); }, kind === 'mt' ? 20000 : 30000);
  }
  stop_worker() { this.buf = {}; clearTimeout(this.ft); this.ft = null; clearTimeout(this.wd); if (this.w) { try { this.w.terminate(); } catch (e) {} } this.w = null; this.cur = null; this.pending = null; this.ready = false; }
  fail(msg) { bootErr = msg; if (this.kind === 'mt') { mtFailed = true; toast('تعدد الأنوية مش شغال على الموبايل ده، رجعت لنواة واحدة'); this.start('lite', this.onReady); } else { $('#best').textContent = 'المحرك مش شغال: ' + msg; } }
  send(c) { if (this.w) this.w.postMessage(c); }
  line(l) {
    if (l === 'uciok') { this.send('setoption name Hash value ' + hashMB()); if (this.kind === 'mt') this.send('setoption name Threads value ' + thrCount()); this.send('isready'); return; }
    if (l === 'readyok') { if (!this.ready) { this.ready = true; clearTimeout(this.wd); if (this.onReady) this.onReady(); } this.next(); return; }
    if (l.startsWith('bestmove')) { this.flush(); const j = this.cur; this.cur = null; const m = l.split(/\s+/)[1]; if (j && !j.cancelled && j.onBest) j.onBest(m); this.next(); return; }
    if (l.startsWith('info') && this.cur && !this.cur.cancelled && this.cur.onInfo) {
      const t = l.split(/\s+/); const g = (k) => { const i = t.indexOf(k); return i >= 0 ? t[i + 1] : null; };
      if (t.includes('lowerbound') || t.includes('upperbound')) return;
      const sc = t.indexOf('score'); if (sc < 0) return;
      const pvi = t.indexOf('pv'); const o = { depth: +g('depth') || 0, nps: +g('nps') || 0, pv: pvi >= 0 ? t.slice(pvi + 1) : [], mpv: +g('multipv') || 1 };
      if (t[sc + 1] === 'cp') o.cp = +t[sc + 2]; else if (t[sc + 1] === 'mate') o.mate = +t[sc + 2]; else return;
      this.buf[o.mpv] = o; if (!this.ft) this.ft = setTimeout(() => this.flush(), 400);
    }
  }
  flush() {
    clearTimeout(this.ft); this.ft = null; const b = this.buf; this.buf = {};
    const j = this.cur; if (!j || j.cancelled || !j.onInfo) return;
    for (const k of Object.keys(b).sort((x, y) => x - y)) { try { j.onInfo(b[k]); } catch (e) {} }
  }
  restart() {
    const j = this.cur || this.pending; this.buf = {}; clearTimeout(this.ft); this.ft = null;
    this.stop_worker(); toast('المحرك وقف ورجّعته تاني');
    this.kindOverride = 'lite'; mtFailed = true; startEngine();
  }
  go(job) { if (this.cur) this.cur.cancelled = true; this.pending = job; if (this.cur) this.send('stop'); else this.next(); }
  cancel() { this.pending = null; if (this.cur) { this.cur.cancelled = true; this.send('stop'); } }
  next() {
    if (!this.ready || this.cur || !this.pending) return;
    const j = this.pending; this.pending = null; this.cur = j;
    (j.opts || []).forEach((o) => this.send('setoption name ' + o));
    this.last = Date.now(); this.jobT = Date.now(); this.send('position fen ' + j.fen); this.send(j.cmd);
  }
}
const eng = new Engine();
setInterval(() => {
  if (document.hidden || !eng.w) return; const now = Date.now();
  if (eng.ready && eng.cur && !eng.cur.cancelled && now - eng.last > 25000 && now - eng.jobT > 25000) { eng.restart(); }
  else if (eng.ready && eng.cur && eng.cur.cancelled && now - eng.jobT > 15000 && now - eng.last > 8000) { eng.restart(); }
}, 3000);

/* ---------------- helpers ---------------- */
let redo = [];
let REVIEW = null, STASH = null, gid = null, GAMES = store.get('zc_games', []);
function canAct() { return !REVIEW && (turnIsHuman() || redo.length > 0); }
function turnIsHuman() { return S.mode === 'free' || game.turn() === humanColor; }
function sqXY(sq) {
  const f = 'abcdefgh'.indexOf(sq[0]), r = +sq[1];
  return [(orient === 'w' ? f : 7 - f) * 100 + 50, (orient === 'w' ? 8 - r : r - 1) * 100 + 50];
}
function uciToMove(u) { return { from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }; }
function pvSan(fen, pv, n) {
  const c = new Chess(fen), out = [];
  for (const u of pv.slice(0, n)) { try { const m = c.move(uciToMove(u)); out.push({ san: m.san, w: m.color === 'w', num: c.moveNumber ? 0 : 0 }); } catch (e) { break; } }
  return out;
}
function evalText(a) {
  if (!a) return '0.00';
  if (a.wm !== undefined) return (a.wm > 0 ? '#' : '-#') + Math.abs(a.wm);
  const v = a.wcp / 100; return (v > 0 ? '+' : '') + v.toFixed(2);
}
let lastBar = 50;
function barPct(a) {
  let wp = null;
  if (a) wp = wpOf(a.wcp, a.wm);
  else { const r = REC[game.fen()]; if (r && !REVIEW) wp = wpOf(r.cp, r.m); }
  if (wp === null) wp = lastBar; lastBar = wp; return wp;
}
function setVBar(wp, txt) {
  const w = $('#vbw'), l = $('#vlab'), bot = orient === 'w';
  w.style.height = wp + '%'; w.style.bottom = bot ? '0' : 'auto'; w.style.top = bot ? 'auto' : '0'; w.style.background = bot ? 'linear-gradient(0deg,#fff,#ddd6ff)' : 'linear-gradient(180deg,#fff,#ddd6ff)';
  if (l) { const whiteAhead = wp >= 50; l.textContent = txt; l.style.color = whiteAhead ? '#1b1426' : '#fff'; const atBottom = whiteAhead === bot; l.style.bottom = atBottom ? '3px' : 'auto'; l.style.top = atBottom ? 'auto' : '3px'; }
}

/* ---------------- rendering ---------------- */
function kingSq(color) { const b = game.board(); for (let r = 0; r < 8; r++) for (let f = 0; f < 8; f++) { const p = b[r][f]; if (p && p.type === 'k' && p.color === color) return 'abcdefgh'[f] + (8 - r); } return null; }
const CL = {
  brilliant: ['!!', '#1baca6', 'رائعة'], great: ['!', '#5c8bb0', 'عظيمة'], best: ['★', '#81b64c', 'الأفضل'], excellent: ['✓', '#96bc4b', 'ممتازة'],
  good: ['•', '#a3b18a', 'جيدة'], inaccuracy: ['?!', '#f7c631', 'دقة ناقصة'], mistake: ['?', '#e58f2a', 'خطأ'], miss: ['✗', '#ff7769', 'فرصة ضايعة'], blunder: ['??', '#ca3431', 'غلطة فادحة'],
};
function liveCls(i) {
  try {
    const hh = game.history({ verbose: true }); const m = hh[i]; if (!m) return null; const r = REC[m.before]; if (!r || r.d < 6) return null;
    const played = m.from + m.to + (m.promotion || ''), w = m.color === 'w';
    const side = (cp, mt) => (w ? wpOf(cp, mt) : 100 - wpOf(cp, mt));
    const wb = side(r.cp, r.m);
    if (played === r.u) {
      if (r.br) return 'brilliant';
      if (r.cp2 !== undefined || r.m2 !== undefined) { const sec = side(r.cp2, r.m2); if (wb - sec >= 8 && wb <= 95) return 'great'; }
      return 'best';
    }
    if (r.bc && played === r.bc.u) return 'brilliant';
    if (/#/.test(m.san)) return 'best';
    const r2 = REC[m.after]; if (!r2 || r2.d < 6) return null;
    const wa = side(r2.cp, r2.m), l = Math.max(0, wb - wa);
    if (l <= 2) return 'excellent'; if (l <= 5) return 'good'; if (l <= 10) return 'inaccuracy'; if (l <= 20) return 'mistake'; return 'blunder';
  } catch (e) { return null; }
}
let vKey = '';
function renderVerdict() {
  const e = $('#verdict'); if (!e) return; const n = game.history().length; const c = n && !REVIEW ? liveCls(n - 1) : null;
  if (!n || REVIEW) { e.innerHTML = ''; return; }
  if (!c) { e.innerHTML = '<span class="vw">بيقيّم النقلة...</span>'; return; }
  const k = CL[c]; const m = game.history({ verbose: true })[n - 1]; const r = REC[m.before]; let extra = '';
  if (r && !['brilliant', 'great', 'best', 'excellent'].includes(c) && r.u) extra = ' · الأفضل كان <b>' + sanOf(m.before, r.u) + '</b>';
  if (c === 'brilliant' && vKey !== renderVerdict.k) { renderVerdict.k = vKey; toast('!! نقلة رائعة', 2500); try { navigator.vibrate && navigator.vibrate([30, 40, 30]); } catch (er) {} }
  e.innerHTML = '<span class="vb" style="background:' + k[1] + '">' + k[0] + '</span> <b style="color:' + k[1] + '">' + m.san + ' ' + k[2] + '</b>' + extra;
}
function liveRefresh() {
  if (REVIEW) return; const n = game.history().length; const key = n + ':' + (n ? liveCls(n - 1) : '') + ':' + game.fen();
  if (key === vKey) return; vKey = key; renderBoard(); renderVerdict(); renderMoves();
}
function renderBoard() {
  const el = $('#board'); el.innerHTML = '';
  const hist = game.history({ verbose: true }); const last = hist[hist.length - 1];
  const targets = {};
  if (sel) game.moves({ square: sel, verbose: true }).forEach((m) => { targets[m.to] = m; });
  const chk = game.isCheck() ? kingSq(game.turn()) : null;
  for (let row = 0; row < 8; row++) for (let col = 0; col < 8; col++) {
    const file = orient === 'w' ? col : 7 - col, rank = orient === 'w' ? 8 - row : row + 1;
    const sq = 'abcdefgh'[file] + rank; const d = document.createElement('div');
    d.className = 'sq ' + ((file + rank) % 2 === 0 ? 'd' : 'l'); d.dataset.sq = sq;
    if (last && (last.from === sq || last.to === sq)) d.classList.add('last');
    if (sel === sq) d.classList.add('sel');
    if (chk === sq) d.classList.add('chk');
    if (S.co) {
      if (col === 0) { const c = document.createElement('span'); c.className = 'co r'; c.textContent = rank; d.appendChild(c); }
      if (row === 7) { const c = document.createElement('span'); c.className = 'co f'; c.textContent = 'abcdefgh'[file]; d.appendChild(c); }
    }
    const p = game.get(sq);
    if (p) { const s = document.createElement('span'); s.className = 'pc ' + p.color; s.textContent = GLYPH[p.type] + '\uFE0E'; d.appendChild(s); }
    if (!REVIEW && last && last.to === sq && hist.length) { const lc = liveCls(hist.length - 1); const c = lc && CL[lc]; if (c) { const b = document.createElement('span'); b.className = 'bdg' + (lc === 'brilliant' ? ' bigb' : ''); b.style.background = c[1]; b.textContent = c[0]; d.appendChild(b); } }
    if (REVIEW && REVIEW.rec.rv && last && last.to === sq) { const c = CL[REVIEW.rec.rv.cls[hist.length - 1]]; if (c) { const b = document.createElement('span'); b.className = 'bdg'; b.style.background = c[1]; b.textContent = c[0]; d.appendChild(b); } }
    if (targets[sq]) { const t = document.createElement('div'); t.className = p || targets[sq].flags.includes('e') ? 'ring' : 'dot'; d.appendChild(t); }
    el.appendChild(d);
  }
  renderArrow();
}
function arrowSvg(u, col, wd, ol) {
  const [x1, y1] = sqXY(u.slice(0, 2)), [x2, y2] = sqXY(u.slice(2, 4));
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, hl = 32, hw = wd * 1.6;
  const ex = x2 - ux * hl, ey = y2 - uy * hl;
  const o = ol ? `<line x1="${x1}" y1="${y1}" x2="${ex}" y2="${ey}" stroke="${ol}" stroke-width="${wd + 12}" stroke-linecap="round"/><polygon points="${x2 + ux * 6},${y2 + uy * 6} ${ex - uy * (hw + 7)},${ey + ux * (hw + 7)} ${ex + uy * (hw + 7)},${ey - ux * (hw + 7)}" fill="${ol}" stroke="${ol}" stroke-width="6" stroke-linejoin="round"/><circle cx="${x1}" cy="${y1}" r="${wd * .75 + 6}" fill="${ol}"/>` : '';
  return o + `<line x1="${x1}" y1="${y1}" x2="${ex}" y2="${ey}" stroke="${col}" stroke-width="${wd}" stroke-linecap="round"/>` +
    `<polygon points="${x2},${y2} ${ex - uy * hw},${ey + ux * hw} ${ex + uy * hw},${ey - ux * hw}" fill="${col}"/>` +
    `<circle cx="${x1}" cy="${y1}" r="${wd * .75}" fill="${col}"/>`;
}
function renderArrow() {
  if (REVIEW) return renderReviewArrow();
  const svg = $('#arrow'); svg.innerHTML = '';
  if (over || !A || A.fen !== game.fen() || !A.pv.length) return;
  if (!(S.ar || hintActive) || !canAct()) return;
  let h = '';
  const br = brillSel(A);
  if (A.sec && A.sec.fen === A.fen && A.sec.pv.length && A.sec.pv[0] !== A.pv[0] && !(br && br.u === A.sec.pv[0])) h += arrowSvg(A.sec.pv[0], 'rgba(61,220,132,.82)', 14);
  if (br && br.top) h += arrowSvg(A.pv[0], '#ff2d3d', 18, '#2f8bff');
  else { h += arrowSvg(A.pv[0], 'rgba(59,156,255,.9)', 18); if (br) h += arrowSvg(br.u, '#ff2d3d', 16, '#2f8bff'); }
  svg.innerHTML = h;
}
function ev2(r) { if (!r) return ''; if (r.m !== undefined) return (r.m > 0 ? '#' : '-#') + Math.abs(r.m); const v = r.cp / 100; return (v > 0 ? '+' : '') + v.toFixed(2); }
function score(r) { return r.m !== undefined ? (r.m > 0 ? 1 : -1) * (10000 - Math.abs(r.m)) : r.cp; }
function renderMoves() {
  if (REVIEW) return renderMovesRv();
  const hh = game.history({ verbose: true }); const n = hh.length; const h = hh.slice(); if (redo.length) { const c = new Chess(game.fen()); for (let k = redo.length - 1; k >= 0; k--) { try { h.push(c.move(redo[k])); } catch (e) { break; } } }
  const el = $('#moves'); let html = '';
  $('#nCnt').textContent = n + ' / ' + h.length; $('#nBack').disabled = $('#nFirst').disabled = n === 0; $('#nFwd').disabled = $('#nLast').disabled = redo.length === 0; $('#bUndo').classList.toggle('off', n === 0); $('#bFwd').classList.toggle('off', !redo.length);
  if (!h.length) { el.innerHTML = '<div class="hd">النقلات وأفضل نقلة في كل دور هتظهر هنا</div>'; return; }
  html = '<div class="hd">كل نقلة، وجنبها أفضل نقلة كان المحرك شايفها في الدور ده</div>';
  for (let i = 0; i < h.length; i++) {
    const m = h[i], r = REC[m.before]; let bst = '', cls = '';
    const lcv = liveCls(i < n ? i : -1); const vtag = lcv ? ' <b style="color:' + CL[lcv][1] + '">' + CL[lcv][0] + '</b>' : '';
    if (r) {
      let sn = '?'; try { sn = new Chess(m.before).move(uciToMove(r.u)).san; } catch (e) {}
      const played = m.from + m.to + (m.promotion || '');
      if (played === r.u) { bst = 'الأفضل: <b>' + sn + '</b> ✓' + (r.br ? ' <span class="brl">!! رائعة</span>' : ''); cls = ' ok'; }
      else if (r.bc && played === r.bc.u) { bst = 'نقلة <b>' + m.san + '</b> <span class="brl">!! رائعة</span>'; cls = ' ok'; }
      else {
        const r2 = REC[m.after]; let tag = '';
        if (r2) { const sg = m.color === 'w' ? 1 : -1; const loss = (score(r) - score(r2)) * sg; tag = loss <= 30 ? ' (قريبة)' : loss <= 100 ? ' (أقل دقة)' : loss <= 250 ? ' (خطأ)' : ' (غلطة كبيرة)'; if (loss <= 30) cls = ' ok'; else cls = ' bad'; }
        bst = 'الأفضل: <b>' + sn + '</b>' + tag + (r.br ? ' <span class="brl">!! كانت رائعة</span>' : '');
      }
    }
    html += '<div class="mv' + (i === n - 1 ? ' cur' : '') + (i >= n ? ' fut' : '') + '" data-p="' + (i + 1) + '"><span class="no">' + (m.color === 'w' ? Math.floor(i / 2) + 1 : '') + '</span><span class="pl ' + m.color + '"></span><span class="san">' + m.san + vtag + '</span><span class="bst' + cls + '">' + bst + '</span><span class="ev">' + (r ? ev2(r) + ' · د' + r.d : '') + '</span></div>';
  }
  el.innerHTML = html; const cu = el.querySelector('.cur'); if (cu) el.scrollTop = Math.max(0, cu.offsetTop - el.clientHeight / 2); else el.scrollTop = 0;
  for (const r of el.querySelectorAll('.mv')) r.onclick = () => jumpTo(+r.dataset.p);
}
function renderStatus() {
  let t = '';
  if (over) t = endText().t;
  else {
    const side = game.turn() === 'w' ? 'الأبيض' : 'الأسود';
    if (S.mode === 'ai') t = turnIsHuman() ? 'دورك' : 'المحرك بيفكر...'; else t = 'دور ' + side + ' - المحرك بيحلل وبيكتب لك أفضل نقلة';
    if (game.isCheck()) t = 'كش! ' + t;
  }
  $('#status').textContent = t;
}
function endText() {
  if (game.isCheckmate()) { const w = game.turn() === 'w' ? 'الأسود' : 'الأبيض'; const you = S.mode === 'ai' ? (game.turn() !== humanColor ? ' مبروك، كسبت!' : ' المحرك كسب.') : ''; return { t: 'كش مات! فاز ' + w + '.' + you, s: '' }; }
  if (game.isStalemate()) return { t: 'تعادل (بات)', s: 'مفيش نقلة قانونية والملك مش في كش.' };
  if (game.isThreefoldRepetition()) return { t: 'تعادل بتكرار الوضع', s: '' };
  if (game.isInsufficientMaterial()) return { t: 'تعادل (مادة غير كافية)', s: '' };
  return { t: 'تعادل (قاعدة الـ50 نقلة)', s: '' };
}
function renderEval() {
  { const bp = barPct(A); $('#barw').style.width = bp + '%'; setVBar(bp, A ? evalText(A) : (REC[game.fen()] && !REVIEW ? ev2(REC[game.fen()]) : '0.0')); } $('#dep').textContent = A ? 'العمق ' + A.depth : 'العمق —';
  $('#evtxt').textContent = A ? evalText(A) : '0.00';
  const best = $('#best'), pv = $('#pv'), meta = $('#meta');
  if (!eng.ready) { best.textContent = bootErr ? 'المحرك مش شغال: ' + bootErr : 'جاري تشغيل المحرك...'; pv.textContent = ''; meta.textContent = ''; return; }
  if (!A) { best.textContent = over ? '' : (S.an || hintActive ? 'بيحلل...' : 'التحليل متوقف. اضغط "أفضل نقلة".'); pv.textContent = ''; meta.textContent = 'Stockfish 19 · NNUE'; return; }
  const fmt = (fen, pvl, n) => { const line = pvSan(fen, pvl, n); const c = new Chess(fen); let k = c.moveNumber(); let isW = c.turn() === 'w'; let t = ''; line.forEach((m, i) => { if (isW) { t += k + '. '; } else if (i === 0) { t += k + '... '; } t += m.san + ' '; if (!isW) k++; isW = !isW; }); return { line, t }; };
  const pv2 = $('#pv2'); pv2.textContent = ''; const pv3 = $('#pv3'); pv3.innerHTML = '';
  if (A.fen === game.fen()) {
    const f1 = fmt(A.fen, A.pv, 10);
    if (f1.line.length) {
      const mine = canAct();
      best.innerHTML = (mine ? 'أفضل نقلة: ' : 'المحرك بيفكر في: ') + '<b class="c1">' + f1.line[0].san + '</b> <small class="c1">' + evalText(A) + '</small>' + (brillSel(A) && brillSel(A).top ? ' <span class="brl">!! رائعة</span>' : '');
      pv.innerHTML = '<span class="c1">● </span>' + f1.t;
      const bs = brillSel(A);
      if (mine && bs && !bs.top) { const f3 = fmt(A.fen, bs.pv, 8); if (f3.line.length) pv3.innerHTML = '<span class="brl">!! رائعة ممكنة</span> <b>' + f3.line[0].san + '</b> <small>(أقل من الأفضل بـ ' + (bs.gap / 100).toFixed(2) + ')</small><div class="pvl">' + f3.t + '</div>'; }
      if (mine && A.sec && A.sec.fen === A.fen && A.sec.pv.length && A.sec.pv[0] !== A.pv[0]) {
        const f2 = fmt(A.fen, A.sec.pv, 8);
        if (f2.line.length) { best.innerHTML += ' &nbsp; ثانية: <b class="c2">' + f2.line[0].san + '</b> <small class="c2">' + evalText(A.sec) + '</small>'; pv2.innerHTML = '<span class="c2">● </span>' + f2.t; }
      }
    }
  }
  meta.textContent = 'Stockfish 19 · NNUE · ' + (eng.kind === 'mt' ? thrCount() + ' أنوية' : 'نواة') + ' · عمق ' + A.depth + ' · ' + (A.nps ? Math.round(A.nps / 1000) + ' ألف نقلة/ث' : '');
}
let evalQueued = false;
function queueEval() { if (evalQueued) return; evalQueued = true; requestAnimationFrame(() => { evalQueued = false; renderEval(); renderArrow(); }); }

/* ---------------- game flow ---------------- */
function opts(forMove) {
  const lvl = LEVELS[S.level] || LEVELS[6];
  if (forMove && lvl.elo <= 0) return ['MultiPV value ' + (S.bm ? 3 : 1), 'UCI_LimitStrength value false'];
  if (forMove && lvl.elo > 0) return ['MultiPV value 1', 'UCI_LimitStrength value true', 'UCI_Elo value ' + lvl.elo];
  return ['MultiPV value ' + (S.bm ? (S.perf === 'max' ? 3 : 2) : 2), 'UCI_LimitStrength value false'];
}
const REC = store.get('zc_rec', {});
const VAL = { p: 1, n: 3, b: 3, r: 5, q: 9 };
function mat(c, color) { let t = 0; for (const row of c.board()) for (const p of row) if (p && p.type !== 'k') t += (p.color === color ? 1 : -1) * VAL[p.type]; return t; }
function sacOK(fen, a) {
  try {
    if (!a || a.depth < 10 || a.pv.length < 2) return false;
    const c = new Chess(fen), me = c.turn(), m0 = mat(c, me);
    c.move(uciToMove(a.pv[0])); c.move(uciToMove(a.pv[1]));
    if (mat(c, me) > m0 - 2) return false;
    if (a.pv.length >= 4) { c.move(uciToMove(a.pv[2])); c.move(uciToMove(a.pv[3])); if (mat(c, me) > m0 - 1) return false; }
    return true;
  } catch (e) { return false; }
}
const sgOf = (fen) => (fen.split(' ')[1] === 'w' ? 1 : -1);
const lsc = (a) => score({ m: a.wm, cp: a.wcp });
function isBrilliant(fen, a) {
  if (!sacOK(fen, a)) return false;
  const sc = lsc(a) * sgOf(fen);
  if (sc < -50 || (sc > 600 && a.wm === undefined)) return false;
  if (a.sec && a.sec.pv.length) { const s2 = lsc(a.sec) * sgOf(fen); if (sc - s2 < 30) return false; }
  return true;
}
// brilliant-mode: look through the MultiPV lines for the best sacrifice that holds
function brilliantCand(fen, a, maxGap) {
  if (!a || !a.pv.length) return null;
  const sg = sgOf(fen), best = lsc(a) * sg; let out = null;
  const lines = [a, ...Object.values(a.lines || {})];
  for (const L of lines) {
    if (!L || !L.pv || !L.pv.length || (L.wcp === undefined && L.wm === undefined)) continue;
    if (!sacOK(fen, L)) continue;
    const sc = lsc(L) * sg; if (sc < -50 || (sc > 600 && L.wm === undefined) || best - sc > maxGap) continue;
    if (!out || sc > out.sc) out = { u: L.pv[0], pv: L.pv, sc, gap: best - sc, line: L, top: L === a };
  }
  return out;
}
function brillSel(a) {
  if (!a) return null;
  if (S.bm) return brilliantCand(a.fen, a, 60);
  return isBrilliant(a.fen, a) ? { u: a.pv[0], pv: a.pv, gap: 0, top: true, line: a } : null;
}
function rec(fen, a) { if (!a.pv.length) return; const r = REC[fen]; clearTimeout(rec.t); rec.t = setTimeout(liveRefresh, 350); if (!r || a.depth >= r.d) REC[fen] = { u: a.pv[0], d: a.depth, cp: a.wcp, m: a.wm, br: !!brillSel(a) && brillSel(a).top, cp2: a.sec && a.sec.pv.length ? a.sec.wcp : undefined, m2: a.sec && a.sec.pv.length ? a.sec.wm : undefined, bc: S.bm ? (() => { const c = brilliantCand(fen, a, 60); return c ? { u: c.u, g: Math.round(c.gap) } : null; })() : null }; }
function infoToA(fen, o) {
  const sign = fen.split(' ')[1] === 'w' ? 1 : -1; const a = { fen, depth: o.depth, nps: o.nps, pv: o.pv };
  if (o.mate !== undefined) a.wm = o.mate * sign; else a.wcp = o.cp * sign; return a;
}
function onAnInfo(fen, o) {
  if (game.fen() !== fen) return;
  if (o.mpv >= 2) { if (A && A.fen === fen) { const l = infoToA(fen, o); A.lines = A.lines || {}; A.lines[o.mpv] = l; if (o.mpv === 2) A.sec = l; } queueEval(); return; }
  const prev = A; A = infoToA(fen, o); A.lines = {}; if (prev && prev.fen === fen) { A.lines = prev.lines || {}; A.sec = prev.sec; }
  rec(fen, A); queueEval();
}
function startAnalysis() {
  if (REVIEW) return;
  if (over) return;
  const fen = game.fen();
  if (!(S.an || hintActive)) { eng.cancel(); return; }
  eng.go({ fen, cmd: anCmd(), opts: opts(false), onInfo: (o) => onAnInfo(fen, o) });
}
function engineMove() {
  if (REVIEW) return;
  if (over) return;
  const fen = game.fen(); thinking = true;
  eng.go({ fen, cmd: 'go movetime ' + S.time, opts: opts(true),
    onInfo: (o) => onAnInfo(fen, o),
    onBest: (u) => { thinking = false; if (game.fen() !== fen || !u || u === '(none)') return; if (S.bm && (LEVELS[S.level] || LEVELS[6]).elo <= 0 && A && A.fen === fen) { const c = brilliantCand(fen, A, 30); if (c && c.u !== u) { u = c.u; toast('المحرك لعب نقلة رائعة!'); } } applyMove(uciToMove(u)); } });
}
function afterChange() {
  if (REVIEW) { over = false; sel = null; renderBoard(); renderMoves(); renderReviewPanel(); return; }
  over = game.isGameOver(); sel = null; renderBoard(); renderMoves(); renderStatus(); saveGame(); renderVerdict();
  if (over) { eng.cancel(); A = null; renderEval(); const e = endText(); $('#endT').textContent = e.t; $('#endS').textContent = e.s; $('#shEnd').classList.add('on'); return; }
  A = null; renderEval();
  if (!eng.ready) return;
  if (!turnIsHuman() && !redo.length) engineMove(); else startAnalysis();
}
function applyMove(m) {
  try { game.move(m); } catch (e) { return false; }
  { const t = redo[redo.length - 1]; const uu = m.from + m.to + (m.promotion || ''); if (t && t.from + t.to + (t.promotion || '') === uu) redo.pop(); else redo = []; }
  try { navigator.vibrate && navigator.vibrate(8); } catch (e) {}
  hintActive = false; thinking = false; afterChange(); return true;
}
let suppress = false;
function onSquare(sq) {
  if (suppress) return;
  if (over || !canAct()) return;
  const p = game.get(sq);
  if (sel) {
    const mv = game.moves({ square: sel, verbose: true }).filter((m) => m.to === sq);
    if (mv.length) {
      if (mv[0].promotion) { pendingPromo = { from: sel, to: sq }; showPromo(); return; }
      applyMove({ from: sel, to: sq }); return;
    }
  }
  if (p && p.color === game.turn()) { sel = sel === sq ? null : sq; renderBoard(); } else { sel = null; renderBoard(); }
}
function showPromo() {
  const box = $('#promoBtns'); box.innerHTML = '';
  ['q', 'r', 'b', 'n'].forEach((t) => {
    const b = document.createElement('button'); b.textContent = GLYPH[t] + '\uFE0E'; b.style.color = game.turn() === 'w' ? '#fff' : '#1b1426';
    b.addEventListener('click', () => { $('#shPromo').classList.remove('on'); const pp = pendingPromo; pendingPromo = null; applyMove({ from: pp.from, to: pp.to, promotion: t }); });
    box.appendChild(b);
  });
  $('#shPromo').classList.add('on');
}
function newGame() {
  gid = null; DEMO = false;
  S.mode = nw.mode; S.level = nw.level; saveSet();
  game.reset(); redo = []; over = false; A = null; hintActive = false; thinking = false; for (const k in REC) delete REC[k];
  humanColor = nw.color === 'r' ? (Math.random() < 0.5 ? 'w' : 'b') : nw.color;
  if (S.mode === 'free') humanColor = 'w';
  orient = humanColor; eng.cancel();
  $('#shNew').classList.remove('on'); $('#shEnd').classList.remove('on');
  afterChange();
}
function navPost() {
  eng.cancel(); thinking = false; hintActive = false; over = false; $('#shEnd').classList.remove('on'); afterChange();
}
function stepBack() { const m = game.undo(); if (!m) return false; redo.push({ from: m.from, to: m.to, promotion: m.promotion }); return true; }
function stepFwd() { const m = redo.pop(); if (!m) return false; game.move(m); return true; }
function undo() { if (stepBack()) navPost(); else toast('ده أول الدور'); }
function fwd() { if (stepFwd()) navPost(); else toast('مفيش نقلات قدام'); }
function jumpTo(ply) {
  ply = Math.max(0, Math.min(ply, game.history().length + redo.length));
  let ch = false;
  while (game.history().length > ply) { if (!stepBack()) break; ch = true; }
  while (game.history().length < ply) { if (!stepFwd()) break; ch = true; }
  if (ch) navPost();
}

/* ---------------- ui wiring ---------------- */
function seg(id, items, get, set) {
  const el = $(id); el.innerHTML = '';
  items.forEach((it) => { const b = document.createElement('button'); b.textContent = it.l; b.dataset.v = it.v; b.className = String(get()) === String(it.v) ? 'on' : ''; b.addEventListener('click', () => { set(it.v); [...el.children].forEach((c) => c.classList.toggle('on', String(c.dataset.v) === String(it.v))); }); el.appendChild(b); });
}
function toggle(id, key, after) {
  const el = $(id); el.classList.toggle('on', !!S[key]);
  el.onclick = () => { S[key] = !S[key]; el.classList.toggle('on', !!S[key]); saveSet(); if (after) after(); };
}
const THEMES = {
  purple: ['بنفسجي', '#e4e0fb', '#7a6fd0'], classic: ['أبيض وأسود', '#f2f2f2', '#3d3d3d'], green: ['أخضر', '#eeeed2', '#769656'],
  wood: ['خشب', '#f0d9b5', '#b58863'], walnut: ['خشب غامق', '#d9b88f', '#7b4a2b'], brown: ['بني', '#e8d0aa', '#a0522d'],
  blue: ['أزرق', '#dee3e6', '#8ca2ad'], ocean: ['محيط', '#d6f0f5', '#2f7f99'], navy: ['كحلي', '#c9d1e8', '#2b3a67'],
  gray: ['رمادي', '#e0e0e0', '#8a8a8a'], red: ['أحمر', '#f6dede', '#b5473f'], rose: ['وردي', '#fde3ec', '#d9648f'],
  mint: ['نعناع', '#e0f5ea', '#4f9d7b'], gold: ['ذهبي', '#fff0bd', '#c89b2a'], orange: ['برتقالي', '#ffe8cf', '#e0802b'], night: ['ليلي', '#6b6f85', '#23253a'],
};
function applyTheme() {
  const th = THEMES[S.theme] || THEMES.purple; const t = S.theme === 'custom' ? [S.cl, S.cd] : [th[1], th[2]];
  const r = document.documentElement.style; r.setProperty('--sl', t[0]); r.setProperty('--sd', t[1]);
  document.documentElement.dataset.theme = S.theme;
}
function syncSettingsUi() {
  const tl = Object.keys(THEMES).map((k) => ({ v: k, l: THEMES[k][0] })).concat([{ v: 'custom', l: 'ألوان من اختيارك' }]);
  seg('#sgTheme', tl, () => S.theme, (v) => { S.theme = v; saveSet(); applyTheme(); $('#cpRow').style.display = v === 'custom' ? 'flex' : 'none'; });
  for (const b of document.querySelectorAll('#sgTheme button')) { const th = THEMES[b.dataset.v]; if (th) b.style.cssText = 'border-right:26px solid ' + th[2] + ';box-shadow:inset -26px 0 0 0 ' + th[1] + ';'; }
  $('#cpRow').style.display = S.theme === 'custom' ? 'flex' : 'none';
  $('#cL').value = S.cl; $('#cD').value = S.cd;
  $('#cL').oninput = (e) => { S.cl = e.target.value; saveSet(); applyTheme(); };
  $('#cD').oninput = (e) => { S.cd = e.target.value; saveSet(); applyTheme(); };
  seg('#sgEng', [{ v: 0, l: 'تلقائي' }, { v: 1, l: 'نواة واحدة' }, { v: 2, l: '2' }, { v: 4, l: '4' }, { v: 6, l: '6' }], () => S.thr, (v) => { v = +v; if (v === S.thr) return; S.thr = v; mtFailed = false; saveSet(); startEngine(); updEngNote(); });
  seg('#sgTime', TIMES.map((t) => ({ v: t, l: t / 1000 + ' ث' })), () => S.time, (v) => { S.time = +v; saveSet(); });
  seg('#sgLevel2', LEVELS.map((l, i) => ({ v: i, l: l.n })), () => S.level, (v) => { S.level = +v; nw.level = +v; saveSet(); });
  toggle('#tgSv', 'sv', () => { if (S.sv) { saveNow(); toast('حفظ الألعاب شغال'); } else { clearTimeout(saveGame.t); toast('حفظ الألعاب مقفول. اللعب مش هيتحفظ.'); } });
  seg('#sgPerf', [{ v: 'safe', l: 'آمن' }, { v: 'bal', l: 'متوازن' }, { v: 'max', l: 'أقصى أداء' }], () => S.perf, (v) => { S.perf = v; S.safe = v === 'safe'; S.thr = 0; mtFailed = false; saveSet(); toast(v === 'max' ? 'أقصى أداء: أنوية أكتر وذاكرة أكبر وتحليل أعمق. الموبايل هيسخن.' : v === 'safe' ? 'الوضع الآمن: أخف حاجة' : 'متوازن'); startEngine(); updEngNote(); });
  toggle('#tgDr', 'dr', () => { sel = null; renderBoard(); });
  toggle('#tgBm', 'bm', () => { if (!over && canAct()) { A = null; renderEval(); startAnalysis(); } });
  toggle('#tgAn', 'an', () => { if (!over && turnIsHuman()) { A = null; renderEval(); startAnalysis(); } });
  toggle('#tgAr', 'ar', renderArrow); toggle('#tgCo', 'co', renderBoard);
  updEngNote();
}
function updEngNote() {
  $('#engNote').textContent = eng.kind === 'mt' ? 'شغال بـ ' + thrCount() + ' أنوية (عدد أنوية الموبايل ' + HC + '). كل ما زادت الأنوية زاد العمق والدقة، بس الموبايل بيسخن أكتر.'
    : (canMT() || S.thr === 1 ? 'شغال بنواة واحدة.' : 'تعدد الأنوية مش متاح هنا، شغال بنواة واحدة.');
}
function startEngine() {
  A = null; bootErr = ''; renderEval();
  eng.start(canMT() ? 'mt' : 'lite', () => { updEngNote(); renderEval(); if (!over && !REVIEW) { if (!turnIsHuman() && !redo.length) engineMove(); else startAnalysis(); } });
}
function openNew() {
  nw.mode = S.mode; nw.level = S.level; nw.color = S.color === 'r' || S.color === 'b' ? S.color : 'w';
  seg('#sgMode', [{ v: 'ai', l: 'ضد المحرك' }, { v: 'free', l: 'لاعبين على نفس الموبايل' }], () => nw.mode, (v) => { nw.mode = v; vis(); });
  seg('#sgColor', [{ v: 'w', l: 'الأبيض' }, { v: 'b', l: 'الأسود' }, { v: 'r', l: 'عشوائي' }], () => nw.color, (v) => { nw.color = v; S.color = v; saveSet(); });
  seg('#sgLevel', LEVELS.map((l, i) => ({ v: i, l: l.n + (l.elo ? ' (~' + l.elo + ')' : '') })), () => nw.level, (v) => { nw.level = +v; });
  function vis() { $('#rwColor').style.display = nw.mode === 'ai' ? '' : 'none'; $('#rwLevel').style.display = nw.mode === 'ai' ? '' : 'none'; }
  vis(); $('#shNew').classList.add('on');
}
$('#bNew').onclick = openNew; $('#cancelNew').onclick = () => $('#shNew').classList.remove('on'); $('#goNew').onclick = newGame;
$('#bSet').onclick = () => { syncSettingsUi(); $('#shSet').classList.add('on'); }; $('#closeSet').onclick = () => $('#shSet').classList.remove('on');
$('#endNew').onclick = () => { $('#shEnd').classList.remove('on'); openNew(); }; $('#endClose').onclick = () => $('#shEnd').classList.remove('on');
$('#bUndo').onclick = undo; $('#bFwd').onclick = fwd;
$('#nBack').onclick = undo; $('#nFwd').onclick = fwd; $('#nFirst').onclick = () => jumpTo(0); $('#nLast').onclick = () => jumpTo(1e9);
$('#bFlip').onclick = () => { orient = orient === 'w' ? 'b' : 'w'; renderBoard(); renderEval(); };
$('#bArrow').onclick = () => { S.ar = !S.ar; saveSet(); renderArrow(); $('#bArrow').classList.toggle('off', !S.ar); toast(S.ar ? 'السهم شغال' : 'السهم مقفول'); };
$('#bHint').onclick = () => {
  if (over) return; if (!canAct()) { toast('استنى دورك'); return; }
  hintActive = true; if (!A || A.fen !== game.fen()) startAnalysis(); else renderArrow(); renderEval();
  if (A && A.pv.length) { const m = pvSan(A.fen, A.pv, 1)[0]; if (m) toast('أفضل نقلة: ' + m.san); }
};
for (const s of document.querySelectorAll('.sheet')) s.addEventListener('click', (e) => { if (e.target === s && s.id !== 'shPromo') s.classList.remove('on'); });
window.addEventListener('contextmenu', (e) => e.preventDefault());
window.__isBr = isBrilliant;
window.__setA = (a) => { A = a; renderEval(); renderArrow(); };
window.__bc = (fen, a, g) => brilliantCand(fen, a, g);
window.__arrowTest = (u) => { $('#arrow').innerHTML = arrowSvg(u, '#ff2d3d', 18, '#2f8bff') + arrowSvg('b1c3', 'rgba(61,220,132,.82)', 14); };
window.__zc = { S, game, eng, get A() { return A; }, onSquare, undo, newGame, nw };

/* ---------------- boot ---------------- */
(function init() {
  const g = store.get('zc_game', null);
  if (g && g.pgn) { try { game.loadPgn(g.pgn); humanColor = g.humanColor || 'w'; orient = g.orient || 'w'; gid = g.gid || null; S.mode = g.mode || S.mode; redo = Array.isArray(g.redo) ? g.redo : []; } catch (e) { game.reset(); } }
  else { humanColor = 'w'; orient = 'w'; }
  over = game.isGameOver(); renderBoard(); renderMoves(); renderStatus(); syncSettingsUi(); startEngine();
})();

window.__back = () => { if (REVIEW && !document.querySelector('.sheet.on')) { exitReview(); return true; } const o = document.querySelector('.sheet.on'); if (o && o.id !== 'shPromo') { o.classList.remove('on'); return true; } return false; };


$('#bArrow').classList.toggle('off', !S.ar);

applyTheme();

/* ---------------- drag and drop ---------------- */
(function () {
  const bd = $('#board'); let dfrom = null, sx = 0, sy = 0, dragging = false, ghost = null, sz = 0, off = 0;
  const sqAt = (x, y) => { const r = bd.getBoundingClientRect(); const c = Math.floor((x - r.left) / r.width * 8), rw = Math.floor((y - r.top) / r.height * 8); if (c < 0 || c > 7 || rw < 0 || rw > 7) return null; const f = orient === 'w' ? c : 7 - c, rk = orient === 'w' ? 8 - rw : rw + 1; return 'abcdefgh'[f] + rk; };
  const clearHi = () => { for (const e of bd.querySelectorAll('.hv')) e.classList.remove('hv'); };
  let pendSq = null, wasSel = false;
  bd.addEventListener('pointerdown', (e) => {
    dragging = false; dfrom = null; pendSq = null; if (e.isPrimary === false) return;
    const sq = sqAt(e.clientX, e.clientY); if (!sq) return;
    if (!S.dr) { onSquare(sq); return; }
    if (over || !canAct()) return;
    const p = game.get(sq);
    if (!p || p.color !== game.turn()) { pendSq = sq; return; }
    dfrom = sq; sx = e.clientX; sy = e.clientY; wasSel = sel === sq;
    if (sel !== sq) { sel = sq; renderBoard(); }
    try { bd.setPointerCapture(e.pointerId); } catch (er) {}
  });
  bd.addEventListener('pointermove', (e) => {
    if (!dfrom) return;
    if (!dragging && Math.hypot(e.clientX - sx, e.clientY - sy) > 8) {
      dragging = true; const r = bd.getBoundingClientRect(); sz = r.width / 8; off = sz * 0.7;
      const p = game.get(dfrom); ghost = document.createElement('div'); ghost.className = 'ghost pc ' + p.color; ghost.textContent = GLYPH[p.type] + '\uFE0E'; ghost.style.fontSize = sz * 1.25 + 'px'; document.body.appendChild(ghost);
      const o = bd.querySelector('[data-sq=' + dfrom + '] .pc'); if (o) o.style.opacity = '.25';
    }
    if (dragging) { ghost.style.left = e.clientX + 'px'; ghost.style.top = e.clientY - off + 'px'; clearHi(); const t = sqAt(e.clientX, e.clientY - off); if (t) { const el = bd.querySelector('[data-sq=' + t + ']'); if (el) el.classList.add('hv'); } }
  });
  const end = (e, cancel) => {
    if (pendSq) { const q = pendSq; pendSq = null; if (!cancel) { const t = sqAt(e.clientX, e.clientY); if (t === q) onSquare(q); } return; }
    if (!dfrom) return; const from = dfrom; dfrom = null;
    if (!dragging) { if (wasSel && !cancel) { sel = null; renderBoard(); } return; }
    dragging = false; if (ghost) { ghost.remove(); ghost = null; } clearHi();
    suppress = true; setTimeout(() => { suppress = false; }, 350);
    const o = bd.querySelector('[data-sq=' + from + '] .pc'); if (o) o.style.opacity = '';
    if (cancel) return;
    const to = sqAt(e.clientX, e.clientY - off); if (!to || to === from) return;
    const mv = game.moves({ square: from, verbose: true }).filter((m) => m.to === to);
    if (!mv.length) { toast('نقلة مش مسموحة'); return; }
    if (mv[0].promotion) { pendingPromo = { from, to }; showPromo(); return; }
    applyMove({ from, to });
  };
  bd.addEventListener('pointerup', (e) => end(e, false));
  bd.addEventListener('pointercancel', (e) => end(e, true));
})();

/* ================= saved games + game review ================= */

const NOTABLE = ['brilliant', 'great', 'miss', 'mistake', 'blunder'];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function newId() { return 'g' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
function fullMoves() { const h = game.history({ verbose: true }).map((m) => ({ from: m.from, to: m.to, promotion: m.promotion })); for (let k = redo.length - 1; k >= 0; k--) h.push(redo[k]); return h; }
let DEMO = false;
function saveRecord() {
  if (REVIEW || DEMO) return;
  const mv = fullMoves(); if (!mv.length) return;
  if (!gid) gid = newId();
  const c = new Chess(); for (const m of mv) { try { c.move(m); } catch (e) { break; } }
  let res = null; if (c.isCheckmate()) res = c.turn() === 'w' ? 'b' : 'w'; else if (c.isGameOver()) res = 'd';
  let r = GAMES.find((x) => x.id === gid);
  if (!r) { r = { id: gid, t0: Date.now() }; GAMES.unshift(r); }
  Object.assign(r, { t1: Date.now(), mode: S.mode, color: humanColor, lvl: S.level, n: mv.length, res, pgn: c.pgn() });
  if (r.rv && r.rv.n !== mv.length) delete r.rv;
  if (GAMES.length > 60) GAMES.length = 60;
  store.set('zc_games', GAMES);
}
function closeSheets() { for (const e of document.querySelectorAll('.sheet.on')) if (e.id !== 'shPromo') e.classList.remove('on'); }
function loadDemo() {
  const mv = '1. e4 e5 2. Nf3 d6 3. d4 Bg4 4. dxe5 Bxf3 5. Qxf3 dxe5 6. Bc4 Nf6 7. Qb3 Qe7 8. Nc3 c6 9. Bg5 b5 10. Nxb5 cxb5 11. Bxb5+ Nbd7 12. O-O-O Rd8 13. Rxd7 Rxd7 14. Rd1 Qe6 15. Bxd7+ Nxd7';
  const c = new Chess(); c.loadPgn(mv);
  eng.cancel(); closeSheets(); gid = null; DEMO = true; S.mode = 'free'; humanColor = 'w'; orient = 'w'; saveSet();
  game.reset(); redo = []; over = false; for (const m of c.history({ verbose: true })) game.move({ from: m.from, to: m.to, promotion: m.promotion });
  const fen = game.fen(); REC[fen] = { u: 'b3b8', d: 99, m: 2, cp: undefined, br: true, bc: null };
  afterChange(); toast('مثال جاهز: لعبة الأوبرا (موغان ضد الدوق). العب كوين b8 كش (Qb8+) وشوف نقلة رائعة!', 6000);
}
function openGames() { renderGames(); $('#shGames').classList.add('on'); }
function renderGames() {
  const el = $('#gList'); el.innerHTML = '';
  { const t = document.createElement('button'); t.className = 'go sec'; t.textContent = 'اختبار الحفظ (' + (NS ? 'تخزين داخلي' : 'متصفح') + ')'; t.onclick = saveTest; el.appendChild(t); const t2 = document.createElement('button'); t2.className = 'go sec'; t2.textContent = '♞ مثال على نقلة رائعة (!!)'; t2.onclick = loadDemo; el.appendChild(t2); }
  if (!GAMES.length) { el.insertAdjacentHTML('beforeend', '<div class="note">لسه مفيش ألعاب محفوظة. أي لعبة تلعبها هتتحفظ هنا لوحدها.</div>'); return; }
  for (const g of GAMES) {
    const d = document.createElement('div'); d.className = 'gc';
    const when = new Date(g.t1 || g.t0).toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' });
    let res = g.res === 'w' ? 'فاز الأبيض' : g.res === 'b' ? 'فاز الأسود' : g.res === 'd' ? 'تعادل' : 'لسه مكتملتش';
    if (g.mode === 'ai' && g.res && g.res !== 'd') res += g.res === g.color ? ' (كسبت)' : ' (خسرت)';
    const mode = g.mode === 'ai' ? 'ضد المحرك' + (LEVELS[g.lvl] ? ' (' + LEVELS[g.lvl].n + ')' : '') + ' · بتلعب ' + (g.color === 'w' ? 'أبيض' : 'أسود') : 'ألعب الجهتين';
    d.innerHTML = '<div class="gt">' + when + '</div><div class="gm">' + mode + '</div><div class="gr' + (g.res ? '' : ' op') + '">' + res + ' · ' + Math.ceil(g.n / 2) + ' نقلة' + (g.rv ? ' · دقة ' + g.rv.acc.w + '% / ' + g.rv.acc.b + '%' : '') + '</div>' +
      '<div class="gb"><button data-a="open">' + (g.res ? 'فتح' : 'كمّل') + '</button><button data-a="rv" class="pr">تحليل</button><button data-a="del" class="dl">حذف</button></div>';
    d.querySelector('[data-a=open]').onclick = () => loadRecord(g.id);
    d.querySelector('[data-a=rv]').onclick = () => { closeSheets(); openReview(g.id); };
    const del = d.querySelector('[data-a=del]');
    del.onclick = () => { if (del.dataset.c !== '1') { del.dataset.c = '1'; del.textContent = 'تأكيد الحذف'; setTimeout(() => { del.dataset.c = ''; del.textContent = 'حذف'; }, 3000); return; }
      GAMES.splice(GAMES.indexOf(g), 1); store.set('zc_games', GAMES); if (gid === g.id) gid = null; renderGames(); };
    el.appendChild(d);
  }
}
function loadRecord(id) {
  const rec = GAMES.find((x) => x.id === id); if (!rec) return;
  if (REVIEW) exitReview(true);
  eng.cancel(); game.reset(); try { game.loadPgn(rec.pgn); } catch (e) { game.reset(); }
  redo = []; humanColor = rec.color || 'w'; orient = humanColor; S.mode = rec.mode || 'ai'; saveSet(); gid = rec.id;
  over = false; hintActive = false; thinking = false; A = null; closeSheets(); afterChange();
}
function openReview(id) {
  const rec = GAMES.find((x) => x.id === id); if (!rec) return;
  if (!REVIEW) STASH = { moves: fullMoves(), ply: game.history().length, humanColor, orient, gid, mode: S.mode };
  else REVIEW.cancel = true;
  eng.cancel(); thinking = false; hintActive = false; over = false; A = null; $('#shEnd').classList.remove('on');
  const c = new Chess(); try { c.loadPgn(rec.pgn); } catch (e) {}
  const mv = c.history({ verbose: true });
  REVIEW = { id, rec, mv, busy: false, cancel: false, prog: 0, cont: false };
  orient = rec.mode === 'ai' ? (rec.color || 'w') : 'w';
  game.reset(); redo = mv.slice().reverse().map((m) => ({ from: m.from, to: m.to, promotion: m.promotion }));
  document.body.classList.add('rv'); closeSheets(); afterChange(); window.scrollTo(0, 0);
}
function exitReview(noAfter) {
  if (!REVIEW) return; $('#rvSum').style.display = 'none'; REVIEW.cancel = true; eng.cancel();
  const st = STASH; REVIEW = null; STASH = null; document.body.classList.remove('rv');
  game.reset(); redo = [];
  if (st) { const mv = st.moves; for (let i = 0; i < st.ply && i < mv.length; i++) { try { game.move(mv[i]); } catch (e) { break; } } for (let i = mv.length - 1; i >= game.history().length; i--) redo.push(mv[i]); humanColor = st.humanColor; orient = st.orient; gid = st.gid; S.mode = st.mode; }
  over = false; A = null; if (!noAfter) afterChange();
}
function wpOf(cp, m) { if (m !== undefined && m !== null) return m > 0 ? 100 : 0; if (cp === undefined || cp === null) return 50; return 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1); }
function analyseFen(f, D, R) {
  return new Promise((res) => {
    const L = {}, sign = f.split(' ')[1] === 'w' ? 1 : -1; let done = false;
    const t = setInterval(() => { if (R.cancel) { clearInterval(t); if (!done) { done = true; res(null); } } }, 200);
    eng.go({ fen: f, cmd: 'go depth ' + D + ' movetime ' + (D >= 24 ? 16000 : D >= 20 ? 9000 : 4000), opts: ['MultiPV value 2', 'UCI_LimitStrength value false'],
      onInfo: (o) => { L[o.mpv] = { d: o.depth, cp: o.cp !== undefined ? o.cp * sign : undefined, m: o.mate !== undefined ? o.mate * sign : undefined, pv: o.pv.slice(0, 8) }; },
      onBest: (u) => { if (done) return; done = true; clearInterval(t); const a = L[1] || { pv: [] }, b = L[2]; res({ u: u && u !== '(none)' ? u : a.pv[0], cp: a.cp, m: a.m, d: a.d, pv: a.pv, cp2: b ? b.cp : undefined, m2: b ? b.m : undefined }); } });
  });
}
async function runReview(D) {
  const R = REVIEW; if (!R || R.busy) return; R.busy = true; R.cancel = false; R.prog = 0; S.rvd = D; saveSet(); renderReviewPanel();
  const c = new Chess(), fens = [c.fen()]; for (const m of R.mv) { c.move({ from: m.from, to: m.to, promotion: m.promotion }); fens.push(c.fen()); }
  const N = R.mv.length, pos = [];
  while (!eng.ready) { if (R.cancel) { R.busy = false; return; } await sleep(200); }
  for (let i = 0; i <= N; i++) {
    if (R.cancel || REVIEW !== R) { R.busy = false; return; }
    const cc = new Chess(fens[i]);
    if (cc.isCheckmate()) pos.push({ term: true, cp: cc.turn() === 'w' ? -10000 : 10000, pv: [] });
    else if (cc.isGameOver()) pos.push({ term: true, cp: 0, pv: [] });
    else { const p = await analyseFen(fens[i], D, R); if (!p) { R.busy = false; return; } pos.push(p); }
    R.prog = (i + 1) / (N + 1); updProg();
  }
  R.rec.rv = computeReview(R.mv, fens, pos, D); R.busy = false; store.set('zc_games', GAMES); renderReviewPanel(); renderMoves(); renderBoard(); renderArrow();
}
function computeReview(mv, fens, pos, D) {
  const N = mv.length, cls = [], loss = [], accs = { w: [], b: [] }, cnt = { w: {}, b: {} }; let prevCls = null;
  const wpW = (i) => wpOf(pos[i].cp, pos[i].m);
  for (let i = 1; i <= N; i++) {
    const m = mv[i - 1], col = m.color, me = col === 'w' ? 1 : -1, pb = pos[i - 1];
    const wb = col === 'w' ? wpW(i - 1) : 100 - wpW(i - 1), wa = col === 'w' ? wpW(i) : 100 - wpW(i);
    const played = m.from + m.to + (m.promotion || ''), isBest = played === pb.u;
    let l = isBest ? 0 : Math.max(0, wb - wa);
    const sec = (pb.cp2 !== undefined || pb.m2 !== undefined) ? (col === 'w' ? wpOf(pb.cp2, pb.m2) : 100 - wpOf(pb.cp2, pb.m2)) : null;
    const mateBefore = pb.m !== undefined && pb.m * me > 0, prevBad = prevCls === 'mistake' || prevCls === 'blunder';
    let c;
    if (isBest || l <= 0.5) {
      c = isBest ? 'best' : 'excellent';
      if (sacOK(fens[i - 1], { depth: 99, pv: pb.pv || [] }) && wa >= 40 && (wb <= 90 || mateBefore) && (isBest || l <= 2)) c = 'brilliant';
      else if (isBest && sec !== null && wb - sec >= 8 && wb <= 95) c = 'great';
    } else if (l <= 2) c = 'excellent'; else if (l <= 5) c = 'good'; else if (l <= 10) c = 'inaccuracy'; else if (l <= 20) c = 'mistake'; else c = 'blunder';
    if ((c === 'inaccuracy' || c === 'mistake' || c === 'blunder') && ((prevBad && l >= 10 && l <= 35) || (mateBefore && l >= 10))) c = 'miss';
    const a = Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * l) - 3.1669));
    accs[col].push(a); cls.push(c); loss.push(Math.round(l * 10) / 10); cnt[col][c] = (cnt[col][c] || 0) + 1; prevCls = c;
  }
  const accOf = (arr) => { if (!arr.length) return 100; const mean = arr.reduce((x, y) => x + y, 0) / arr.length, harm = arr.length / arr.reduce((x, y) => x + 1 / Math.max(y, 1), 0); return Math.round((mean + harm) / 2 * 10) / 10; };
  return { d: D, n: N, cls, loss, acc: { w: accOf(accs.w), b: accOf(accs.b) }, cnt,
    pos: pos.map((p) => ({ u: p.u, cp: p.cp, m: p.m, pv: (p.pv || []).slice(0, 6), cp2: p.cp2, m2: p.m2, d: p.d, term: p.term })) };
}
function updProg() { const R = REVIEW; if (!R) return; { const b = $('#sBar'), t = $('#sPt'); if (b) b.style.width = Math.round(R.prog * 100) + '%'; if (t) t.textContent = 'بيحلل الأوضاع... ' + Math.round(R.prog * 100) + '%'; } $('#rvBar').style.width = Math.round(R.prog * 100) + '%'; $('#rvPt').textContent = 'بيحلل الأوضاع... ' + Math.round(R.prog * 100) + '%'; }
function sanOf(fen, u) { try { return new Chess(fen).move(uciToMove(u)).san; } catch (e) { return u; } }
function renderMovesRv() {
  const R = REVIEW, el = $('#moves'), n = game.history().length, rv = R.rec.rv, mv = R.mv;
  $('#nCnt').textContent = n + ' / ' + mv.length; $('#nBack').disabled = $('#nFirst').disabled = n === 0; $('#nFwd').disabled = $('#nLast').disabled = n >= mv.length;
  let html = '<div class="hd">' + (rv ? 'دوس على أي نقلة تروح لها' : 'النقلات (حلّل اللعبة عشان يظهر تقييم كل نقلة)') + '</div>';
  mv.forEach((m, i) => {
    const c = rv ? CL[rv.cls[i]] : null;
    html += '<div class="mv' + (i === n - 1 ? ' cur' : '') + '" data-p="' + (i + 1) + '"><span class="no">' + (m.color === 'w' ? Math.floor(i / 2) + 1 : '') + '</span><span class="pl ' + m.color + '"></span><span class="san">' + m.san + '</span><span class="bst" style="color:' + (c ? c[1] : '') + '">' + (c ? '<b style="color:' + c[1] + '">' + c[0] + '</b> ' + c[2] : '') + '</span><span class="ev">' + (rv ? evTxt(rv.pos[i + 1]) : '') + '</span></div>';
  });
  el.innerHTML = html; const cu = el.querySelector('.cur'); if (cu) el.scrollTop = Math.max(0, cu.offsetTop - el.clientHeight / 2); else el.scrollTop = 0;
  for (const r of el.querySelectorAll('.mv')) r.onclick = () => jumpTo(+r.dataset.p);
}
function evTxt(p) { if (!p) return ''; if (p.m !== undefined) return (p.m > 0 ? '#' : '-#') + Math.abs(p.m); const v = (p.cp || 0) / 100; if (Math.abs(v) >= 99) return v > 0 ? '1-0' : '0-1'; return (v > 0 ? '+' : '') + v.toFixed(2); }
function renderReviewArrow() {
  const svg = $('#arrow'); svg.innerHTML = ''; const R = REVIEW; if (!R || !R.rec.rv) return;
  const n = game.history().length; if (n === 0) return; const rv = R.rec.rv, m = R.mv[n - 1], c = rv.cls[n - 1], pb = rv.pos[n - 1], played = m.from + m.to + (m.promotion || '');
  if (c === 'brilliant') svg.innerHTML = arrowSvg(played, '#ff2d3d', 18, '#2f8bff');
  else if (pb && pb.u && pb.u !== played && !['excellent', 'good'].includes(c) || (pb && pb.u && pb.u !== played && S.rvAll)) svg.innerHTML = arrowSvg(pb.u, 'rgba(59,156,255,.9)', 18);
}
function renderReviewPanel() {
  const R = REVIEW; if (!R) return; renderSum(); const rv = R.rec.rv, n = game.history().length;
  $('#rvStart').style.display = !rv && !R.busy ? 'block' : 'none'; $('#rvProg').style.display = R.busy ? 'block' : 'none'; $('#rvMain').style.display = rv ? 'block' : 'none';
  if (!rv) {
    seg('#rvDepth', [{ v: 12, l: 'سريع (عمق 12)' }, { v: 16, l: 'عادي (عمق 16)' }, { v: 20, l: 'عميق (عمق 20)' }, { v: 24, l: 'أقصى (عمق 24)' }], () => S.rvd || 16, (v) => { S.rvd = +v; saveSet(); });
    $('#rvEst').textContent = 'اللعبة ' + R.mv.length + ' نقلة. التحليل بيشتغل على الموبايل بدون نت وممكن ياخد من نص دقيقة لكام دقيقة حسب العمق والموبايل.';
    $('#evtxt').textContent = '0.00'; setVBar(50, '0.0'); $('#dep').textContent = 'العمق —'; if (R.busy) updProg(); return;
  }
  const p = rv.pos[n]; const wp = wpOf(p.cp, p.m);
  setVBar(wp, evTxt(p)); $('#evtxt').textContent = evTxt(p); $('#dep').textContent = 'العمق ' + (p.d || rv.d);
  // move card
  let card = '';
  if (n === 0) card = '<div class="rc0">بداية اللعبة. دوس ▶ أو اختار نقلة من القايمة أو من الرسم.</div>';
  else {
    const m = R.mv[n - 1], c = rv.cls[n - 1], cl = CL[c], pb = rv.pos[n - 1], played = m.from + m.to + (m.promotion || '');
    card = '<div class="rch"><span class="rbadge" style="background:' + cl[1] + '">' + cl[0] + '</span><b class="rsan">' + m.san + '</b><span class="rlab" style="color:' + cl[1] + '">' + cl[2] + '</span><span class="rev">' + evTxt(p) + '</span></div>';
    if (pb && pb.u && pb.u !== played) card += '<div class="rbest">الأفضل كان: <b>' + sanOf(m.before, pb.u) + '</b> <small>(' + evTxt(pb) + ')</small>' + (rv.loss[n - 1] >= 5 ? ' · خسارة ' + rv.loss[n - 1] + '% من فرصة الفوز' : '') + '</div>';
    else if (c === 'brilliant') card += '<div class="rbest">تضحية سليمة. المحرك شايفها الأفضل.</div>';
    else card += '<div class="rbest">نقلة المحرك المفضلة.</div>';
  }
  $('#rvCard').innerHTML = card;
  renderGraph(n);
  // accuracy + counts
  const keys = Object.keys(CL).filter((k) => (rv.cnt.w[k] || 0) + (rv.cnt.b[k] || 0) > 0);
  let a = '<div class="acr"><div class="acw"><small>الأبيض</small><b>' + rv.acc.w + '%</b></div><div class="acb"><small>الأسود</small><b>' + rv.acc.b + '%</b></div></div><div class="cnt">';
  for (const k of keys) a += '<div class="cr"><span>' + (rv.cnt.w[k] || 0) + '</span><span class="cn" style="color:' + CL[k][1] + '"><i style="background:' + CL[k][1] + '">' + CL[k][0] + '</i>' + CL[k][2] + '</span><span>' + (rv.cnt.b[k] || 0) + '</span></div>';
  $('#rvAcc').innerHTML = a + '</div><div class="note">الدقة محسوبة بصيغة تقريبية (قريبة من اللي بتستخدمها lichess)، مش صيغة chess.com بالظبط.</div>';
  // critical moments
  const crit = []; rv.cls.forEach((c, i) => { if (NOTABLE.includes(c)) crit.push(i + 1); });
  let h = ''; for (const i of crit) { const c = CL[rv.cls[i - 1]]; h += '<button class="chip' + (i === n ? ' on' : '') + '" data-p="' + i + '" style="border-color:' + c[1] + '"><i style="background:' + c[1] + '">' + c[0] + '</i>' + Math.ceil(i / 2) + (i % 2 ? '. ' : '... ') + R.mv[i - 1].san + '</button>'; }
  $('#rvCrit').innerHTML = h || '<div class="note">مفيش لحظات حاسمة. اللعبة كانت نضيفة.</div>';
  for (const b of $('#rvCrit').querySelectorAll('.chip')) b.onclick = () => jumpTo(+b.dataset.p);
  $('#rvPrevC').onclick = () => { const t = crit.filter((i) => i < n).pop(); if (t) jumpTo(t); else toast('مفيش قبل كده'); };
  $('#rvNextC').onclick = () => { const t = crit.find((i) => i > n); if (t) jumpTo(t); else toast('مفيش بعد كده'); };
}
function renderGraph(n) {
  const rv = REVIEW.rec.rv, N = rv.n, W = 300, H = 90, xs = (i) => (N ? i / N * W : 0);
  const pts = rv.pos.map((p, i) => [xs(i), H - wpOf(p.cp, p.m) / 100 * H]);
  let svg = '<rect width="' + W + '" height="' + H + '" rx="10" fill="#2b2840"/><path d="M0,' + H + ' ' + pts.map((p) => 'L' + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ') + ' L' + W + ',' + H + ' Z" fill="#f2f2f2"/><line x1="0" x2="' + W + '" y1="' + H / 2 + '" y2="' + H / 2 + '" stroke="#8a86a8" stroke-dasharray="3 3" stroke-width="1"/>';
  rv.cls.forEach((c, i) => { if (NOTABLE.includes(c)) svg += '<circle cx="' + pts[i + 1][0].toFixed(1) + '" cy="' + pts[i + 1][1].toFixed(1) + '" r="3.6" fill="' + CL[c][1] + '" stroke="#000" stroke-width=".6"/>'; });
  svg += '<line x1="' + xs(n) + '" x2="' + xs(n) + '" y1="0" y2="' + H + '" stroke="#f06292" stroke-width="2"/>';
  const g = $('#rvGraph'); g.innerHTML = svg;
  g.onclick = (e) => { const r = g.getBoundingClientRect(); jumpTo(Math.round((e.clientX - r.left) / r.width * N)); };
}
$('#bGames').onclick = openGames; $('#gClose').onclick = () => $('#shGames').classList.remove('on');
$('#rvExit').onclick = () => exitReview();
const RATE = [[40, 300], [55, 600], [65, 800], [75, 1100], [82, 1400], [88, 1700], [92, 1950], [95, 2200], [97, 2450], [99, 2700], [100, 2800]];
function accToElo(a) { if (a <= RATE[0][0]) return RATE[0][1]; for (let i = 1; i < RATE.length; i++) if (a <= RATE[i][0]) { const [x0, y0] = RATE[i - 1], [x1, y1] = RATE[i]; return Math.round((y0 + (y1 - y0) * (a - x0) / (x1 - x0)) / 50) * 50; } return 2800; }
function coachLine(rv, me) {
  const c = rv.cnt[me] || {}, acc = rv.acc[me], bl = (c.blunder || 0), mi = (c.mistake || 0), ms = (c.miss || 0), br = (c.brilliant || 0), gr = (c.great || 0);
  if (br > 0) return 'عندك ' + (br > 1 ? br + ' نقلات رائعة' : 'نقلة رائعة') + ' في اللعبة دي. تضحية صح في الوقت الصح.';
  if (bl >= 2) return 'فيه ' + bl + ' غلطات فادحة قلبت اللعبة. شوف اللحظات الحاسمة عشان تعرف فين ضاعت.';
  if (bl === 1) return 'غلطة فادحة واحدة هي اللي غيّرت النتيجة. باقي لعبك كان كويس.';
  if (acc >= 95) return 'لعب ممتاز جداً، قريب من نقلات المحرك طول اللعبة.';
  if (mi + ms >= 3) return 'كام خطأ وفرصة ضايعة في النص. راجعهم واحدة واحدة.';
  if (gr > 0) return 'نقلات عظيمة في اللحظات المهمة. لعب موضعي كويس.';
  if (acc >= 80) return 'لعب كويس وثابت. شوية دقة زيادة وهتكسب أكتر.';
  return 'اللعبة فيها نقلات مش دقيقة. المراجعة هتوريك الأفضل في كل مرحلة.';
}
function sumGraph(rv) {
  const N = rv.pos.length, W = 300, H = 80; if (N < 2) return '';
  const y = (i) => H - wpOf(rv.pos[i].cp, rv.pos[i].m) / 100 * H, x = (i) => i / (N - 1) * W;
  let d = 'M0,' + H; for (let i = 0; i < N; i++) d += ' L' + x(i).toFixed(1) + ',' + y(i).toFixed(1); d += ' L' + W + ',' + H + ' Z';
  let svg = '<rect width="300" height="80" fill="#3a3646"/><path d="' + d + '" fill="#f1eefc"/><line x1="0" x2="300" y1="40" y2="40" stroke="#8a84a3" stroke-width=".6" stroke-dasharray="3 3"/>';
  rv.cls.forEach((c, i) => { if (['brilliant', 'great', 'mistake', 'miss', 'blunder'].includes(c)) svg += '<circle cx="' + x(i + 1).toFixed(1) + '" cy="' + y(i + 1).toFixed(1) + '" r="3.2" fill="' + CL[c][1] + '" stroke="#fff" stroke-width=".8"/>'; });
  return svg;
}
let sumMore = false;
function renderSum() {
  const R = REVIEW, el = $('#rvSum'); if (!el) return;
  if (!R || R.cont) { el.style.display = 'none'; return; }
  el.style.display = 'block'; const rv = R.rec.rv;
  const ai = R.rec.mode === 'ai', you = ai ? (R.rec.color || 'w') : null;
  const nm = (c) => ai ? (c === you ? 'أنت' : 'المحرك') : c === 'w' ? 'الأبيض' : 'الأسود';
  let h = '<div class="sh"><button class="sb" id="sBack" aria-label="رجوع"><svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg></button><h2>مراجعة اللعبة</h2><span></span></div>';
  if (!rv) {
    h += '<div class="sc">' + (R.busy ? '<div id="sPt">بيحلل...</div><div class="pbar"><div id="sBar"></div></div><button class="go sec" id="sCancel">إلغاء</button>'
      : '<div class="note">اللعبة ' + R.mv.length + ' نقلة. التحليل بيشتغل على الموبايل بدون نت وممكن ياخد من نص دقيقة لكام دقيقة.</div><div class="row"><label>عمق التحليل</label><div class="seg" id="sDepth"></div></div><button class="go" id="sGo">ابدأ التحليل</button>') + '</div>';
    el.innerHTML = h; $('#sBack').onclick = () => { exitReview(); openGames(); };
    if (R.busy) { updProg(); $('#sCancel').onclick = () => $('#rvCancel').click(); }
    else { seg('#sDepth', [{ v: 12, l: 'سريع' }, { v: 16, l: 'عادي' }, { v: 20, l: 'عميق' }, { v: 24, l: 'أقصى' }], () => S.rvd || 16, (v) => { S.rvd = +v; saveSet(); }); $('#sGo').onclick = () => runReview(+(S.rvd || 16)); }
    return;
  }
  const me = ai ? you : (rv.acc.w >= rv.acc.b ? 'w' : 'b'), cl = coachLine(rv, me);
  const col = (c) => '<div class="pl2 ' + c + '"><div class="av ' + c + '"></div><b>' + nm(c) + '</b></div>';
  const row = (k) => '<div class="cr2"><span class="lb"><i class="ic" style="background:' + CL[k][1] + '">' + CL[k][0] + '</i><em>' + CL[k][2] + '</em></span><span style="color:' + CL[k][1] + '">' + (rv.cnt.w[k] || 0) + '</span><span style="color:' + CL[k][1] + '">' + (rv.cnt.b[k] || 0) + '</span></div>';
  const main = ['brilliant', 'great', 'best', 'mistake', 'miss', 'blunder'], more = ['excellent', 'good', 'inaccuracy'];
  h += '<div class="sc coach"><div class="cav">♞</div><div class="bub">' + cl + '</div></div>';
  h += '<div class="sc"><svg id="sGraph" viewBox="0 0 300 80" preserveAspectRatio="none">' + sumGraph(rv) + '</svg></div>';
  h += '<div class="sc"><div class="g3"><span></span>' + col('w') + col('b') + '</div><div class="g3"><label>الدقة</label><b class="accb">' + rv.acc.w + '</b><b class="accb">' + rv.acc.b + '</b></div>';
  h += main.map(row).join('') + (sumMore ? more.map(row).join('') : '') + '<button class="mr" id="sMore">' + (sumMore ? '▲' : '▼') + '</button>';
  const ew = accToElo(rv.acc.w), eb = accToElo(rv.acc.b);
  h += '<div class="g3"><label>تقييم اللعبة (تقديري)</label><b class="accb">≈' + ew + '</b><b class="accb">≈' + eb + '</b></div>';
  h += '<div class="note sm2">التقييم تقدير بس: بنحوّل نسبة الدقة لرقم بجدول تقريبي بتاعنا. مش تقييم رسمي ومش نفس معادلة chess.com، وبيتأثر بقصر اللعبة وعمق التحليل.</div></div>';
  h += '<button class="go big" id="sCont">كمّل المراجعة</button>';
  el.innerHTML = h;
  $('#sBack').onclick = () => { exitReview(); openGames(); };
  $('#sMore').onclick = () => { sumMore = !sumMore; renderSum(); };
  $('#sCont').onclick = () => { R.cont = true; el.style.display = 'none'; jumpTo(0); renderReviewPanel(); window.scrollTo(0, 0); };
}
$('#rvSumBtn').onclick = () => { if (REVIEW) { REVIEW.cont = false; renderSum(); $('#rvSum').scrollTop = 0; } };
$('#rvGo').onclick = () => runReview(+(S.rvd || 16));
$('#rvCancel').onclick = () => { if (REVIEW) { REVIEW.cancel = true; REVIEW.busy = false; eng.cancel(); renderReviewPanel(); } };
$('#rvRe').onclick = () => { if (REVIEW) { delete REVIEW.rec.rv; store.set('zc_games', GAMES); renderReviewPanel(); renderMoves(); renderBoard(); renderArrow(); } };
$('#endRv').onclick = () => { $('#shEnd').classList.remove('on'); if (gid) openReview(gid); };
window.__rv = { runReview, openReview, get R() { return REVIEW; }, GAMES };
